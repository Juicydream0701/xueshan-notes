半导体物理 2026-2027 秋学期回忆卷源码

main.tex 与 figure/ 配套使用，建议使用 XeLaTeX + ctex 环境。
保留原始 TEX 和配图；未包含 aux、log、synctex 等构建缓存。
本包不包含大题回忆.docx 内的私人协作链接。
原 PDF 是网页原页阅读的依据，源码包不另行声称已校正题面。
